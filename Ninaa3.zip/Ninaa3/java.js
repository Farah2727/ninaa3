const images = [
  "pic/12.png", "pic/12.png",
  "pic/1.jpg", "pic/1.jpg",
  "pic/2.jpg", "pic/2.jpg",
  "pic/3.jpg", "pic/3.jpg",
  "pic/4.png", "pic/4.png",
  "pic/5.jpg", "pic/5.jpg",
  "pic/6.jpg", "pic/6.jpg",
  "pic/7.jpg", "pic/7.jpg",
  "pic/8.jpg", "pic/8.jpg",
  "pic/9.jpg", "pic/9.jpg",
  "pic/10.jpg", "pic/10.jpg",
  "pic/11.jpg", "pic/11.jpg",
  "pic/13.png", "pic/13.png",
  "pic/14.jpg", "pic/14.jpg",
  "pic/15.jpg", "pic/15.jpg",
];

let shuffledImages = [];
let flippedCards = [];
let matchedPairs = 0;
let redTeamPoints = 0;
let blueTeamPoints = 0;
let currentTeam = "red";

function shuffleImages() {
  shuffledImages = [...images].sort(() => 0.5 - Math.random());
  renderBoard();
}

function renderBoard() {
  const gameBoard = document.getElementById("gameBoard");
  gameBoard.innerHTML = ""; // مسح المحتوى القديم
  shuffledImages.forEach((image, index) => {
    const card = document.createElement("div");
    card.classList.add("card");
    card.dataset.index = index;


    const cardFront = document.createElement("div");
    cardFront.classList.add("card-front");
    cardFront.textContent = index + 1;

    const cardImage = document.createElement("img");
    cardImage.src = image;

    card.appendChild(cardFront);
    card.appendChild(cardImage);
    gameBoard.appendChild(card);

    card.addEventListener("click", () => flipCard(card));
  });
}


function flipCard(card) {
  if (flippedCards.length < 2 && !card.classList.contains("flipped")) {
    card.classList.add("flipped");
    flippedCards.push(card);

    if (flippedCards.length === 2) {
      checkMatch();
    }
  }
}


function checkMatch() {
  const [firstCard, secondCard] = flippedCards;
  const firstImage = shuffledImages[firstCard.dataset.index];
  const secondImage = shuffledImages[secondCard.dataset.index];

  if (firstImage === secondImage) {
    matchedPairs++;
    flippedCards = [];

    if (currentTeam === "red") {
      redTeamPoints += 15;
      alert(`الفريق الأحمر فاز بهذه الجولة! النقاط الحالية: ${redTeamPoints}`);
      // انتقال الدور مباشرة إلى الفريق الأزرق
      currentTeam = "blue";
      alert(`الآن دور الفريق الأزرق!`);
    } else {
      blueTeamPoints += 15;
      alert(`الفريق الأزرق فاز بهذه الجولة! النقاط الحالية: ${blueTeamPoints}`);
      // انتقال الدور مباشرة إلى الفريق الأحمر
      currentTeam = "red";
      alert(`الآن دور الفريق الأحمر!`);
    }

    updateScore();

  } else {
    setTimeout(() => {
      firstCard.classList.remove("flipped");
      secondCard.classList.remove("flipped");
      flippedCards = [];

      // تغيير الدور بعد إجابة خاطئة
      currentTeam = (currentTeam === "red") ? "blue" : "red";
      alert(`الفريق ${currentTeam === "red" ? "الأحمر" : "الأزرق"} سيبدأ الجولة الآن!`);
    }, 1000);
  }
}

function updateScore() {
  document.getElementById("redTeamScore").textContent = redTeamPoints;
  document.getElementById("blueTeamScore").textContent = blueTeamPoints;
}

document.getElementById("shuffleButton").addEventListener("click", shuffleImages);
shuffleImages();
